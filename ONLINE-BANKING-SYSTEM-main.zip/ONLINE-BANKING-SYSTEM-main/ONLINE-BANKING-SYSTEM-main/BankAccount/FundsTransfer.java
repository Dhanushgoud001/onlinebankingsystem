package BankAccount;


public class FundsTransfer {
    public static void transfer(Account sender, Account recipient, double amount) throws BankAccountException {
        // Check if the sender has sufficient balance
        if (sender.getBalance() >= amount) {
            // Deduct the amount from the sender's account
            sender.withdraw(amount);
            // Add the amount to the recipient's account
            recipient.deposit(amount);
            // Record the transaction in transaction history (You need to implement this)
            // Assuming TransactionHistory is a class or data structure, you should create an instance of it and call a method to record the transaction.
            // For example, if you have a TransactionHistory class:
            // TransactionHistory.recordTransaction(sender, recipient, amount);
        } else {
            throw new BankAccountException("Insufficient funds for transfer");
        }
    }
}


