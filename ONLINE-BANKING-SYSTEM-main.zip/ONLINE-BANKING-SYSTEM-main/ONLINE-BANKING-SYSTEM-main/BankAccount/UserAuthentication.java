package BankAccount;

public class UserAuthentication {
        private String username;
        private String password;
        private String pin;

        // Constructors, getters, and setters

        public boolean authenticate(String inputUsername, String inputPassword) {
            return username.equals(inputUsername) && password.equals(inputPassword);
        }

// In your BankMain class:
// Implement user registration, login, and PIN code validation logic

}
